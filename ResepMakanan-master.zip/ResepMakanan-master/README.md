# Build from Android Studio 2.3.3

## Import Project
### Use Git

* Pilih VCS Check out Project --> Git
* Masukkan URL git
* Klik Clone

> Masih error?
> udah install git?
> Masih error? (saya juga bingung) coba googling.


### Download

* Pilih Open an Exiting Project
* Pilih direktori folder yang didownlod tadi

> Masih error? (saya juga bingung) coba googling

# Preview
![alt text](preview/ss1.png)
![alt text](preview/ss2.png)
